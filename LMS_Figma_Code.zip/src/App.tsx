import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Landing from './pages/Landing';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import CourseManagement from './pages/CourseManagement';
import Assessment from './pages/Assessment';
import UserManagement from './pages/UserManagement';
import Layout from './components/Layout';
function ProtectedRoute({
  children,
  allowedRoles
}: {
  children: React.ReactNode;
  allowedRoles?: string[];
}) {
  const {
    user
  } = useAuth();
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/dashboard" replace />;
  }
  return <>{children}</>;
}
function AppContent() {
  const {
    user
  } = useAuth();
  return <Routes>
      <Route path="/" element={user ? <Navigate to="/dashboard" replace /> : <Landing />} />
      <Route path="/login" element={user ? <Navigate to="/dashboard" replace /> : <Login />} />
      <Route path="/dashboard" element={<ProtectedRoute>
            <Layout>
              <Dashboard />
            </Layout>
          </ProtectedRoute>} />
      <Route path="/courses" element={<ProtectedRoute allowedRoles={['Administrator', 'Trainer']}>
            <Layout>
              <CourseManagement />
            </Layout>
          </ProtectedRoute>} />
      <Route path="/assessment" element={<ProtectedRoute allowedRoles={['Student']}>
            <Layout>
              <Assessment />
            </Layout>
          </ProtectedRoute>} />
      <Route path="/users" element={<ProtectedRoute allowedRoles={['Administrator']}>
            <Layout>
              <UserManagement />
            </Layout>
          </ProtectedRoute>} />
    </Routes>;
}
export function App() {
  return <BrowserRouter>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </BrowserRouter>;
}