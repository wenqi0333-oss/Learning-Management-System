import React, { useState } from 'react';
import { UploadIcon, FileTextIcon, VideoIcon, PlusIcon } from 'lucide-react';
export default function CourseManagement() {
  const [courses, setCourses] = useState([{
    id: 1,
    name: 'Introduction to React',
    status: 'Active',
    videos: 12,
    materials: 8
  }, {
    id: 2,
    name: 'Advanced JavaScript',
    status: 'Active',
    videos: 15,
    materials: 10
  }, {
    id: 3,
    name: 'Web Design Basics',
    status: 'Draft',
    videos: 5,
    materials: 3
  }]);
  return <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Course Management</h1>
        <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2">
          <PlusIcon size={20} />
          Create New Course
        </button>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <button className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow text-left">
          <div className="bg-blue-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
            <VideoIcon size={24} className="text-blue-600" />
          </div>
          <h3 className="font-semibold text-gray-800 mb-2">Upload Video</h3>
          <p className="text-sm text-gray-600">
            Add new video lectures to your courses
          </p>
        </button>
        <button className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow text-left">
          <div className="bg-green-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
            <FileTextIcon size={24} className="text-green-600" />
          </div>
          <h3 className="font-semibold text-gray-800 mb-2">Upload Material</h3>
          <p className="text-sm text-gray-600">Add PDF, PPT, or DOC files</p>
        </button>
        <button className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow text-left">
          <div className="bg-purple-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
            <UploadIcon size={24} className="text-purple-600" />
          </div>
          <h3 className="font-semibold text-gray-800 mb-2">View Submissions</h3>
          <p className="text-sm text-gray-600">Check student assignments</p>
        </button>
      </div>
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-800">Your Courses</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Course Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Videos
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Materials
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {courses.map(course => <tr key={course.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="font-medium text-gray-800">
                      {course.name}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-3 py-1 rounded-full text-sm ${course.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-gray-200 text-gray-700'}`}>
                      {course.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                    {course.videos}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                    {course.materials}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex gap-2">
                      <button className="text-blue-600 hover:text-blue-700 font-medium">
                        Edit
                      </button>
                      <button className="text-gray-600 hover:text-gray-700 font-medium">
                        View
                      </button>
                    </div>
                  </td>
                </tr>)}
            </tbody>
          </table>
        </div>
      </div>
    </div>;
}