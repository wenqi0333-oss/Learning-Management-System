import React from 'react';
import { useAuth } from '../context/AuthContext';
import { BookOpenIcon, UsersIcon, TrendingUpIcon, ClockIcon } from 'lucide-react';
export default function Dashboard() {
  const {
    user
  } = useAuth();
  if (user?.role === 'Administrator') {
    return <AdminDashboard />;
  } else if (user?.role === 'Trainer') {
    return <TrainerDashboard />;
  } else {
    return <StudentDashboard />;
  }
}
function AdminDashboard() {
  const stats = [{
    label: 'Total Users',
    value: '1,234',
    icon: UsersIcon,
    color: 'bg-blue-500'
  }, {
    label: 'Active Courses',
    value: '45',
    icon: BookOpenIcon,
    color: 'bg-green-500'
  }, {
    label: 'Total Trainers',
    value: '28',
    icon: UsersIcon,
    color: 'bg-purple-500'
  }, {
    label: 'Total Students',
    value: '1,150',
    icon: TrendingUpIcon,
    color: 'bg-orange-500'
  }];
  return <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">
        Administrator Dashboard
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
        const Icon = stat.icon;
        return <div key={index} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <Icon size={24} className="text-white" />
                </div>
              </div>
              <h3 className="text-gray-600 text-sm mb-1">{stat.label}</h3>
              <p className="text-3xl font-bold text-gray-800">{stat.value}</p>
            </div>;
      })}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">
            Recent User Activity
          </h2>
          <div className="space-y-3">
            {['John Doe logged in', 'Jane Smith completed Course A', 'Mike Johnson uploaded new material'].map((activity, index) => <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <ClockIcon size={16} className="text-gray-400" />
                <span className="text-sm text-gray-700">{activity}</span>
              </div>)}
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">
            System Overview
          </h2>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-600">Storage Used</span>
                <span className="font-medium text-gray-800">65%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-600 h-2 rounded-full" style={{
                width: '65%'
              }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-600">Active Sessions</span>
                <span className="font-medium text-gray-800">342</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-green-600 h-2 rounded-full" style={{
                width: '82%'
              }}></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>;
}
function TrainerDashboard() {
  const courses = [{
    name: 'Introduction to React',
    students: 45,
    status: 'Active'
  }, {
    name: 'Advanced JavaScript',
    students: 32,
    status: 'Active'
  }, {
    name: 'Web Design Basics',
    students: 28,
    status: 'Draft'
  }];
  return <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">
        Trainer Dashboard
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-blue-500 p-3 rounded-lg">
              <BookOpenIcon size={24} className="text-white" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm mb-1">Courses Created</h3>
          <p className="text-3xl font-bold text-gray-800">12</p>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-green-500 p-3 rounded-lg">
              <UsersIcon size={24} className="text-white" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm mb-1">Total Students</h3>
          <p className="text-3xl font-bold text-gray-800">156</p>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-purple-500 p-3 rounded-lg">
              <TrendingUpIcon size={24} className="text-white" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm mb-1">Avg. Completion</h3>
          <p className="text-3xl font-bold text-gray-800">78%</p>
        </div>
      </div>
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-gray-800">Your Courses</h2>
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
            Create New Course
          </button>
        </div>
        <div className="space-y-4">
          {courses.map((course, index) => <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <h3 className="font-semibold text-gray-800">{course.name}</h3>
                <p className="text-sm text-gray-600">
                  {course.students} students enrolled
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className={`px-3 py-1 rounded-full text-sm ${course.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-gray-200 text-gray-700'}`}>
                  {course.status}
                </span>
                <button className="text-blue-600 hover:text-blue-700 font-medium">
                  Edit
                </button>
              </div>
            </div>)}
        </div>
      </div>
    </div>;
}
function StudentDashboard() {
  const courses = [{
    name: 'Introduction to React',
    progress: 75,
    nextExam: '2 days'
  }, {
    name: 'Advanced JavaScript',
    progress: 45,
    nextExam: '5 days'
  }, {
    name: 'Web Design Basics',
    progress: 90,
    nextExam: 'Completed'
  }];
  return <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">
        Student Dashboard
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-blue-500 p-3 rounded-lg">
              <BookOpenIcon size={24} className="text-white" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm mb-1">Enrolled Courses</h3>
          <p className="text-3xl font-bold text-gray-800">3</p>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-green-500 p-3 rounded-lg">
              <TrendingUpIcon size={24} className="text-white" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm mb-1">Avg. Progress</h3>
          <p className="text-3xl font-bold text-gray-800">70%</p>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-orange-500 p-3 rounded-lg">
              <ClockIcon size={24} className="text-white" />
            </div>
          </div>
          <h3 className="text-gray-600 text-sm mb-1">Upcoming Exams</h3>
          <p className="text-3xl font-bold text-gray-800">2</p>
        </div>
      </div>
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-6">My Courses</h2>
        <div className="space-y-4">
          {courses.map((course, index) => <div key={index} className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-gray-800">{course.name}</h3>
                <span className="text-sm text-gray-600">
                  Next exam: {course.nextExam}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex-1">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{
                  width: `${course.progress}%`
                }}></div>
                  </div>
                </div>
                <span className="text-sm font-medium text-gray-700">
                  {course.progress}%
                </span>
              </div>
            </div>)}
        </div>
      </div>
    </div>;
}