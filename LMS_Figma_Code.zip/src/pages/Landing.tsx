import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpenIcon, UsersIcon, FileTextIcon, TrendingUpIcon, CheckCircleIcon, ChevronDownIcon, PlayCircleIcon, GraduationCapIcon, BarChartIcon, FacebookIcon, TwitterIcon, LinkedinIcon, InstagramIcon } from 'lucide-react';
export default function Landing() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const features = [{
    icon: UsersIcon,
    title: 'Create Accounts & Roles',
    description: 'Set up Administrator, Trainer, and Student accounts with role-based access control.'
  }, {
    icon: PlayCircleIcon,
    title: 'Upload Videos & Materials',
    description: 'Share video lectures, PDFs, presentations, and other learning resources easily.'
  }, {
    icon: FileTextIcon,
    title: 'Online Assessments',
    description: 'Create and grade MCQ and short-answer exams with automated tracking.'
  }, {
    icon: BarChartIcon,
    title: 'Progress Tracking',
    description: 'Monitor student progress, completion rates, and performance analytics.'
  }];
  const courses = [{
    title: 'Introduction to React',
    trainer: 'Sarah Johnson',
    tag: 'Web Development',
    thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=250&fit=crop'
  }, {
    title: 'Advanced JavaScript',
    trainer: 'Mike Chen',
    tag: 'Programming',
    thumbnail: 'https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?w=400&h=250&fit=crop'
  }, {
    title: 'UI/UX Design Fundamentals',
    trainer: 'Emma Davis',
    tag: 'Design',
    thumbnail: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=400&h=250&fit=crop'
  }];
  const steps = [{
    number: '01',
    title: 'Sign Up',
    description: 'Create your account and choose your role: Student, Trainer, or Administrator.'
  }, {
    number: '02',
    title: 'Create & Upload',
    description: 'Build courses, upload videos and materials, or enroll in existing courses.'
  }, {
    number: '03',
    title: 'Assess & Track',
    description: 'Take exams, monitor progress, and achieve your learning goals.'
  }];
  const pricingPlans = [{
    name: 'Student',
    price: 'Free',
    description: 'Perfect for learners',
    features: ['Access to all courses', 'Take assessments', 'Progress tracking', 'Certificate of completion']
  }, {
    name: 'Trainer',
    price: '$29',
    period: '/month',
    description: 'For educators',
    features: ['Create unlimited courses', 'Upload videos & materials', 'Create assessments', 'Student analytics', 'Priority support'],
    highlighted: true
  }, {
    name: 'Organization',
    price: '$99',
    period: '/month',
    description: 'For institutions',
    features: ['Everything in Trainer', 'User management', 'Custom branding', 'Advanced analytics', 'Dedicated support', 'API access']
  }];
  const faqs = [{
    question: 'How do I create different types of accounts?',
    answer: 'When you sign up, you can choose between Student, Trainer, or Administrator roles. Each role has specific permissions and features tailored to your needs.'
  }, {
    question: 'What types of content can I upload?',
    answer: 'Trainers can upload videos, PDFs, PowerPoint presentations, Word documents, and other educational materials. All files are securely stored and easily accessible to enrolled students.'
  }, {
    question: 'How do online exams work?',
    answer: 'Our platform supports both multiple-choice questions (MCQ) and short-answer format exams. Students can take timed assessments, and trainers can review and grade submissions directly in the platform.'
  }, {
    question: 'Is my data secure and private?',
    answer: 'Yes, we use industry-standard encryption and security measures to protect your data. All user information and course content is stored securely and never shared with third parties.'
  }, {
    question: 'What kind of support do you offer?',
    answer: 'We provide email support for all users, with priority support for Trainer and Organization plans. Our help center includes detailed documentation, video tutorials, and FAQs.'
  }];
  return <div className="min-h-screen w-full bg-white">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-8">
              <Link to="/" className="text-2xl font-bold text-blue-600">
                LMS
              </Link>
              <div className="hidden md:flex gap-6">
                <a href="#courses" className="text-gray-700 hover:text-blue-600 font-medium">
                  Courses
                </a>
                <a href="#pricing" className="text-gray-700 hover:text-blue-600 font-medium">
                  Pricing
                </a>
                <a href="#about" className="text-gray-700 hover:text-blue-600 font-medium">
                  About
                </a>
                <a href="#faq" className="text-gray-700 hover:text-blue-600 font-medium">
                  FAQ
                </a>
                <a href="#contact" className="text-gray-700 hover:text-blue-600 font-medium">
                  Contact
                </a>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Link to="/login" className="px-4 py-2 text-gray-700 hover:text-blue-600 font-medium">
                Login
              </Link>
              <Link to="/login" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium">
                Sign Up
              </Link>
            </div>
          </div>
        </div>
      </nav>
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-blue-50 to-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-5xl font-bold text-gray-900 mb-6">
              Learn. Teach. Assess—All in One LMS.
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Create accounts, upload videos and learning materials, take MCQ
              and short-answer exams, and track progress—all in one powerful
              platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/login" className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold text-lg">
                Get Started
              </Link>
              <a href="#courses" className="px-8 py-3 bg-white text-blue-600 border-2 border-blue-600 rounded-lg hover:bg-blue-50 transition-colors font-semibold text-lg">
                Browse Courses
              </a>
            </div>
          </div>
        </div>
      </section>
      {/* Value Props */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Everything You Need to Succeed
            </h2>
            <p className="text-lg text-gray-600">
              Powerful features designed for modern learning
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
            const Icon = feature.icon;
            return <div key={index} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow">
                  <div className="bg-blue-100 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                    <Icon size={24} className="text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>;
          })}
          </div>
        </div>
      </section>
      {/* Featured Courses */}
      <section id="courses" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Featured Courses
            </h2>
            <p className="text-lg text-gray-600">
              Explore our most popular learning paths
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {courses.map((course, index) => <div key={index} className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow">
                <img src={course.thumbnail} alt={course.title} className="w-full h-48 object-cover" />
                <div className="p-6">
                  <span className="inline-block px-3 py-1 bg-blue-100 text-blue-600 text-sm font-medium rounded-full mb-3">
                    {course.tag}
                  </span>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {course.title}
                  </h3>
                  <p className="text-gray-600 mb-4">By {course.trainer}</p>
                  <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors font-medium">
                    View Details
                  </button>
                </div>
              </div>)}
          </div>
        </div>
      </section>
      {/* How It Works */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              How It Works
            </h2>
            <p className="text-lg text-gray-600">
              Get started in three simple steps
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((step, index) => <div key={index} className="text-center">
                <div className="bg-blue-600 text-white w-16 h-16 rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                  {step.number}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {step.title}
                </h3>
                <p className="text-gray-600">{step.description}</p>
              </div>)}
          </div>
        </div>
      </section>
      {/* Pricing Preview */}
      <section id="pricing" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Simple, Transparent Pricing
            </h2>
            <p className="text-lg text-gray-600">
              Choose the plan that fits your needs
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {pricingPlans.map((plan, index) => <div key={index} className={`bg-white rounded-lg p-8 ${plan.highlighted ? 'border-2 border-blue-600 shadow-xl' : 'border border-gray-200'}`}>
                {plan.highlighted && <span className="inline-block px-3 py-1 bg-blue-600 text-white text-sm font-medium rounded-full mb-4">
                    Most Popular
                  </span>}
                <h3 className="text-2xl font-bold text-gray-900 mb-2">
                  {plan.name}
                </h3>
                <p className="text-gray-600 mb-4">{plan.description}</p>
                <div className="mb-6">
                  <span className="text-4xl font-bold text-gray-900">
                    {plan.price}
                  </span>
                  {plan.period && <span className="text-gray-600">{plan.period}</span>}
                </div>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, fIndex) => <li key={fIndex} className="flex items-start gap-2">
                      <CheckCircleIcon size={20} className="text-green-600 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{feature}</span>
                    </li>)}
                </ul>
                <button className={`w-full py-3 rounded-lg font-semibold transition-colors ${plan.highlighted ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-gray-100 text-gray-900 hover:bg-gray-200'}`}>
                  Get Started
                </button>
              </div>)}
          </div>
        </div>
      </section>
      {/* FAQ */}
      <section id="faq" className="py-20 bg-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-lg text-gray-600">
              Everything you need to know about LMS
            </p>
          </div>
          <div className="space-y-4">
            {faqs.map((faq, index) => <div key={index} className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                <button onClick={() => setOpenFaq(openFaq === index ? null : index)} className="w-full px-6 py-4 flex items-center justify-between text-left hover:bg-gray-50 transition-colors" aria-expanded={openFaq === index} aria-controls={`faq-answer-${index}`}>
                  <span className="font-semibold text-gray-900">
                    {faq.question}
                  </span>
                  <ChevronDownIcon size={20} className={`text-gray-600 transition-transform ${openFaq === index ? 'transform rotate-180' : ''}`} />
                </button>
                {openFaq === index && <div id={`faq-answer-${index}`} className="px-6 pb-4 text-gray-600">
                    {faq.answer}
                  </div>}
              </div>)}
          </div>
        </div>
      </section>
      {/* Footer */}
      <footer id="contact" className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-xl font-bold mb-4">LMS</h3>
              <p className="text-gray-400">
                Empowering education through technology
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#courses" className="text-gray-400 hover:text-white">
                    Courses
                  </a>
                </li>
                <li>
                  <a href="#pricing" className="text-gray-400 hover:text-white">
                    Pricing
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-400 hover:text-white">
                    Features
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#about" className="text-gray-400 hover:text-white">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-400 hover:text-white">
                    Careers
                  </a>
                </li>
                <li>
                  <a href="#contact" className="text-gray-400 hover:text-white">
                    Contact
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="text-gray-400 hover:text-white">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-400 hover:text-white">
                    Terms of Service
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-400 hover:text-white">
                    Cookie Policy
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              © 2024 LMS. All rights reserved.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-gray-400 hover:text-white" aria-label="Facebook">
                <FacebookIcon size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white" aria-label="Twitter">
                <TwitterIcon size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white" aria-label="LinkedIn">
                <LinkedinIcon size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white" aria-label="Instagram">
                <InstagramIcon size={20} />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>;
}