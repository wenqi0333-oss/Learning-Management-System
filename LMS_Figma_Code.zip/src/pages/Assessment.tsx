import React, { useEffect, useState, useContext, useReducer, memo } from 'react';
import { ClockIcon, ChevronLeftIcon, ChevronRightIcon } from 'lucide-react';
export default function Assessment() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<{
    [key: number]: string;
  }>({});
  const [showResults, setShowResults] = useState(false);
  const questions = [{
    id: 1,
    question: 'What is the virtual DOM in React?',
    type: 'mcq',
    options: ['A copy of the real DOM kept in memory', 'A database for storing component state', 'A styling framework', 'A testing library']
  }, {
    id: 2,
    question: 'Explain the concept of React Hooks in your own words.',
    type: 'short'
  }, {
    id: 3,
    question: 'Which hook is used for side effects in React?',
    type: 'mcq',
    options: ['useState', 'useEffect', 'useContext', 'useReducer']
  }];
  const handleAnswer = (questionId: number, answer: string) => {
    setAnswers({
      ...answers,
      [questionId]: answer
    });
  };
  const handleSubmit = () => {
    setShowResults(true);
  };
  if (showResults) {
    return <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-10 h-10 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-4">
            Assessment Submitted!
          </h2>
          <p className="text-gray-600 mb-8">
            Your answers have been recorded and will be reviewed by your
            instructor.
          </p>
          <div className="bg-gray-50 rounded-lg p-6 mb-6">
            <h3 className="font-semibold text-gray-800 mb-4">Summary</h3>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-blue-600">
                  {questions.length}
                </p>
                <p className="text-sm text-gray-600">Total Questions</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-green-600">
                  {Object.keys(answers).length}
                </p>
                <p className="text-sm text-gray-600">Answered</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-600">
                  {questions.length - Object.keys(answers).length}
                </p>
                <p className="text-sm text-gray-600">Skipped</p>
              </div>
            </div>
          </div>
          <button onClick={() => window.location.href = '/dashboard'} className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
            Back to Dashboard
          </button>
        </div>
      </div>;
  }
  const question = questions[currentQuestion];
  return <div className="max-w-6xl mx-auto">
      <div className="bg-white rounded-lg shadow mb-6 p-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-800">
            Introduction to React - Final Assessment
          </h1>
          <div className="flex items-center gap-2 bg-red-50 px-4 py-2 rounded-lg">
            <ClockIcon size={20} className="text-red-600" />
            <span className="font-semibold text-red-600">45:00</span>
          </div>
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3">
          <div className="bg-white rounded-lg shadow p-8">
            <div className="mb-6">
              <span className="text-sm text-gray-600">
                Question {currentQuestion + 1} of {questions.length}
              </span>
              <h2 className="text-xl font-semibold text-gray-800 mt-2">
                {question.question}
              </h2>
            </div>
            {question.type === 'mcq' ? <div className="space-y-3">
                {question.options?.map((option, index) => <label key={index} className="flex items-center p-4 border-2 border-gray-200 rounded-lg cursor-pointer hover:border-blue-500 transition-colors">
                    <input type="radio" name={`question-${question.id}`} value={option} checked={answers[question.id] === option} onChange={e => handleAnswer(question.id, e.target.value)} className="mr-3 w-4 h-4 text-blue-600" />
                    <span className="text-gray-700">{option}</span>
                  </label>)}
              </div> : <textarea value={answers[question.id] || ''} onChange={e => handleAnswer(question.id, e.target.value)} className="w-full h-40 p-4 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:outline-none" placeholder="Type your answer here..." />}
            <div className="flex items-center justify-between mt-8">
              <button onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))} disabled={currentQuestion === 0} className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-800 disabled:opacity-50 disabled:cursor-not-allowed">
                <ChevronLeftIcon size={20} />
                Previous
              </button>
              {currentQuestion === questions.length - 1 ? <button onClick={handleSubmit} className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors">
                  Submit Assessment
                </button> : <button onClick={() => setCurrentQuestion(Math.min(questions.length - 1, currentQuestion + 1))} className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Next
                  <ChevronRightIcon size={20} />
                </button>}
            </div>
          </div>
        </div>
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow p-6 sticky top-6">
            <h3 className="font-semibold text-gray-800 mb-4">
              Question Navigator
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {questions.map((_, index) => <button key={index} onClick={() => setCurrentQuestion(index)} className={`w-full aspect-square rounded-lg font-medium transition-colors ${currentQuestion === index ? 'bg-blue-600 text-white' : answers[questions[index].id] ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                  {index + 1}
                </button>)}
            </div>
            <button className="w-full mt-6 bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors">
              Save Progress
            </button>
          </div>
        </div>
      </div>
    </div>;
}