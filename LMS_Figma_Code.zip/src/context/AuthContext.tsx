import React, { useState, createContext, useContext } from 'react';
interface User {
  email: string;
  role: 'Administrator' | 'Trainer' | 'Student';
  name: string;
}
interface AuthContextType {
  user: User | null;
  login: (email: string, password: string, role: string) => void;
  logout: () => void;
  signup: (email: string, password: string, role: string, name: string) => void;
}
const AuthContext = createContext<AuthContextType | undefined>(undefined);
export function AuthProvider({
  children
}: {
  children: ReactNode;
}) {
  const [user, setUser] = useState<User | null>(null);
  const login = (email: string, password: string, role: string) => {
    // Simulate login
    setUser({
      email,
      role: role as User['role'],
      name: email.split('@')[0]
    });
  };
  const signup = (email: string, password: string, role: string, name: string) => {
    // Simulate signup
    setUser({
      email,
      role: role as User['role'],
      name
    });
  };
  const logout = () => {
    setUser(null);
  };
  return <AuthContext.Provider value={{
    user,
    login,
    logout,
    signup
  }}>
      {children}
    </AuthContext.Provider>;
}
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}