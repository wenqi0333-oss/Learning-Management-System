import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboardIcon, BookOpenIcon, FileTextIcon, UsersIcon, LogOutIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
export default function Sidebar() {
  const location = useLocation();
  const {
    user,
    logout
  } = useAuth();
  const isActive = (path: string) => location.pathname === path;
  const navItems = [{
    path: '/dashboard',
    label: 'Dashboard',
    icon: LayoutDashboardIcon,
    roles: ['Administrator', 'Trainer', 'Student']
  }, {
    path: '/courses',
    label: 'Course Management',
    icon: BookOpenIcon,
    roles: ['Administrator', 'Trainer']
  }, {
    path: '/assessment',
    label: 'Assessment',
    icon: FileTextIcon,
    roles: ['Student']
  }, {
    path: '/users',
    label: 'User Management',
    icon: UsersIcon,
    roles: ['Administrator']
  }];
  const filteredNavItems = navItems.filter(item => user && item.roles.includes(user.role));
  return <div className="w-64 bg-white border-r border-gray-200 flex flex-col">
      <div className="p-6 border-b border-gray-200">
        <h1 className="text-2xl font-bold text-blue-600">Learning Hub</h1>
      </div>
      <nav className="flex-1 p-4 space-y-2">
        {filteredNavItems.map(item => {
        const Icon = item.icon;
        return <Link key={item.path} to={item.path} className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${isActive(item.path) ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>
              <Icon size={20} />
              <span className="font-medium">{item.label}</span>
            </Link>;
      })}
      </nav>
      <div className="p-4 border-t border-gray-200">
        <button onClick={logout} className="flex items-center gap-3 px-4 py-3 rounded-lg text-gray-700 hover:bg-gray-50 w-full transition-colors">
          <LogOutIcon size={20} />
          <span className="font-medium">Logout</span>
        </button>
      </div>
    </div>;
}