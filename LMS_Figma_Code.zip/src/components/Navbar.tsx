import React from 'react';
import { BellIcon, UserIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
export default function Navbar() {
  const {
    user
  } = useAuth();
  return <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
      <div>
        <h2 className="text-xl font-semibold text-gray-800">
          Welcome back, {user?.name}!
        </h2>
        <p className="text-sm text-gray-600">{user?.role}</p>
      </div>
      <div className="flex items-center gap-4">
        <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors relative">
          <BellIcon size={20} className="text-gray-600" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
        </button>
        <div className="flex items-center gap-2 px-3 py-2 bg-gray-100 rounded-lg">
          <UserIcon size={20} className="text-gray-600" />
          <span className="text-sm font-medium text-gray-700">
            {user?.email}
          </span>
        </div>
      </div>
    </div>;
}