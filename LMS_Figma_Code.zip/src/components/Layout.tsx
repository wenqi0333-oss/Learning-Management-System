import React from 'react';
import Sidebar from './Sidebar';
import Navbar from './Navbar';
export default function Layout({
  children
}: {
  children: React.ReactNode;
}) {
  return <div className="min-h-screen w-full bg-gray-100 flex">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <Navbar />
        <main className="flex-1 p-6 overflow-auto">{children}</main>
      </div>
    </div>;
}