import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import examApi from "../api/examApi";
import { useAuth } from "../context/AuthContext";

// Use a mock question for the UI first, and later switch to fetching it from the backend.
const mockQuestions = [
  {
    id: 1,
    type: "MCQ",
    content: "What does LMS stand for?",
    options: ["Learning Management System", "Local Management Service", "Other"],
  },
  {
    id: 2,
    type: "SA",
    content: "Briefly describe what JWT is used for.",
  },
];

const ExamPage = () => {
  const { id } = useParams(); // examId
  const { user } = useAuth();
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [loading, setLoading] = useState(true);
  const [submitStatus, setSubmitStatus] = useState(null);

  useEffect(() => {
    // In a real project the questions should be fetched from the backend; here they are simulated with a mock.
    setQuestions(mockQuestions);
    setLoading(false);
  }, [id]);

  const handleMCQChange = (questionId, option) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: option,
    }));
  };

  const handleSAChange = (questionId, text) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: text,
    }));
  };

  const handleSubmit = async () => {
    // Convert to the backend's agreed format
    const answerArray = Object.entries(answers)
      .map(([questionId, value]) => {
        const q = questions.find((item) => item.id === Number(questionId));
        if (!q) return null;
        if (q.type === "MCQ") {
          return {
            questionId: q.id,
            selectedOption: value,
          };
        }
        return {
          questionId: q.id,
          answerText: value,
        };
      })
      .filter(Boolean);

    try {
      setSubmitStatus({ loading: true });
      const res = await examApi.submitExam(id, {
        answers: answerArray,
        studentId: user.id,
      });
      if (res.data.success) {
        setSubmitStatus({
          loading: false,
          score: res.data.data.score,
          status: res.data.data.status,
          message: res.data.data.message,
        });
      } else {
        setSubmitStatus({
          loading: false,
          error: res.data.message || "Submit failed",
        });
      }
    } catch (err) {
      console.error(err);
      setSubmitStatus({
        loading: false,
        error: err.response?.data?.message || "Submit failed",
      });
    }
  };

  if (loading) {
    return <div style={{ padding: 16 }}>Loading exam...</div>;
  }

  return (
    <div style={{ padding: 16, maxWidth: 800, margin: "0 auto" }}>
      <h2>Exam #{id}</h2>
      {questions.map((q) => (
        <div
          key={q.id}
          style={{
            border: "1px solid #ccc",
            padding: 12,
            marginBottom: 12,
            borderRadius: 4,
          }}
        >
          <p>
            <strong>Q{q.id}.</strong> {q.content}{" "}
            <span style={{ fontSize: 12, color: "#666" }}>({q.type})</span>
          </p>

          {q.type === "MCQ" && (
            <div>
              {q.options.map((opt) => (
                <label key={opt} style={{ display: "block" }}>
                  <input
                    type="radio"
                    name={`q-${q.id}`}
                    value={opt}
                    checked={answers[q.id] === opt}
                    onChange={() => handleMCQChange(q.id, opt)}
                  />
                  {opt}
                </label>
              ))}
            </div>
          )}

          {q.type === "SA" && (
            <textarea
              rows={3}
              style={{ width: "100%" }}
              value={answers[q.id] || ""}
              onChange={(e) => handleSAChange(q.id, e.target.value)}
            />
          )}
        </div>
      ))}

      <button onClick={handleSubmit}>Submit Exam</button>

      {submitStatus?.loading && <p>Submitting...</p>}
      {submitStatus?.error && (
        <p style={{ color: "red" }}>Error: {submitStatus.error}</p>
      )}
      {submitStatus && !submitStatus.loading && !submitStatus.error && (
        <div style={{ marginTop: 16 }}>
          <p>Score: {submitStatus.score}</p>
          <p>Status: {submitStatus.status}</p>
          <p>{submitStatus.message}</p>
        </div>
      )}
    </div>
  );
};

export default ExamPage;