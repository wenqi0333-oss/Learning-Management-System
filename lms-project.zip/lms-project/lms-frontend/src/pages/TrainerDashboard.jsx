import React, { useState } from "react";

const TrainerDashboard = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploadStatus, setUploadStatus] = useState("");

  const handleFileChange = (e) => {
    setSelectedFile(e.target.files[0]);
    setUploadStatus("");
  };

  const handleUpload = () => {
    if (!selectedFile) {
      setUploadStatus("Please select a file.");
      return;
    }
    // This is just a demonstration, not a real upload
    setUploadStatus("Uploading (demo only, not real upload)...");
    setTimeout(() => {
      setUploadStatus("Upload success (demo).");
    }, 1500);
  };

  return (
    <div style={{ padding: 16 }}>
      <h2>Trainer Portal</h2>
      <div style={{ marginTop: 20 }}>
        <h3>Upload Video / Material (Demo)</h3>
        <input type="file" onChange={handleFileChange} />
        <button onClick={handleUpload} style={{ marginLeft: 8 }}>
          Upload
        </button>
        {uploadStatus && (
          <p style={{ marginTop: 8 }}>Status: {uploadStatus}</p>
        )}
      </div>
    </div>
  );
};

export default TrainerDashboard;