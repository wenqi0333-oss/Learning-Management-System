import React from "react";
import { Link } from "react-router-dom";

const StudentDashboard = () => {
  return (
    <div style={{ padding: 16 }}>
      <h2>Student Portal</h2>
      <p>Welcome to your learning dashboard.</p>
      <p>
        <Link to="/exam/1">Go to Exam #1</Link>
      </p>
    </div>
  );
};

export default StudentDashboard;