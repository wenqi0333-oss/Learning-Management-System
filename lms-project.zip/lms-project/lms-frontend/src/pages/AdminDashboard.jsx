import React from "react";
import { useAuth } from "../context/AuthContext";

const AdminDashboard = () => {
  const { user } = useAuth();

  return (
    <div style={{ padding: 16 }}>
      <h2>Admin Portal</h2>
      <p>Welcome, {user?.name}</p>
      <p>Here admin can manage users and content (to be implemented).</p>
    </div>
  );
};

export default AdminDashboard;