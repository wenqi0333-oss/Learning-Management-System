import axiosClient from "./axiosClient";

const examApi = {
  submitExam(examId, data) {
    // POST /api/v1/exams/:id/submit
    return axiosClient.post(`/exams/${examId}/submit`, data);
  },
};

export default examApi;