import axiosClient from "./axiosClient";

const authApi = {
  login(data) {
    // POST /api/v1/auth/login
    return axiosClient.post("/auth/login", data);
  },
  register(data) {
    // POST /api/v1/auth/register
    return axiosClient.post("/auth/register", data);
  },
};

export default authApi;