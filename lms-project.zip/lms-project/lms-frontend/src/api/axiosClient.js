import axios from "axios";

const axiosClient = axios.create({
// Note: The address here must match the address where your backend is actually running
  baseURL: "http://localhost:4000/api/v1",
});

// Automatically attach JWT token to each request
axiosClient.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default axiosClient;