import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

/**
 * For protecting routes + simple front-end role control
 * Example：
 * <ProtectedRoute roles={['admin']}>
 *   <AdminDashboard />
 * </ProtectedRoute>
 */
const ProtectedRoute = ({ roles, children }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return <div>Loading...</div>;
  }

  // Not logged in — redirect to the login page
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // If roles are provided and the current user's role is not among them, access is not permitted.
  if (roles && !roles.includes(user.role)) {
    return <Navigate to="/" replace />;
  }

  return children;
};

export default ProtectedRoute;